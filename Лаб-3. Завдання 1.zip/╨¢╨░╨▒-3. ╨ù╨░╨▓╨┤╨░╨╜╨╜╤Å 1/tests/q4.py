test = {   'name': 'q4',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> len(my_info_long) == 9\nTrue', 'hidden': False, 'locked': False},
                                   {'code': ">>> isinstance(my_info_long['course'], int)\nTrue", 'hidden': False, 'locked': False},
                                   {'code': ">>> isinstance(my_info_long['budget'], bool)\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
