test = {   'name': 'q2',
    'points': 1,
    'suites': [{'cases': [{'code': '>>> isinstance(my_info["month_of_birth"], str)\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
